<?php
session_start();
session_unset();
http_response_code(200);
